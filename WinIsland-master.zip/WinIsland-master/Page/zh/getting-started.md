# 快速开始

准备好在你的 Windows 桌面上体验WinIsland了吗？按照以下简单的步骤来运行 WinIsland。

## 安装

1.  **下载**：前往 [下载页面](/zh/download) 获取正式版或预览版安装程序。
2.  **安装**：运行安装程序，并保留默认安装位置。
3.  **权限**：允许 Windows 管理员提示，使安装程序能够注册 WinIsland 的 Windows 身份并启用通知访问等功能。

## 基础操作

- **点击**：点击灵动岛将其展开，显示工具。
- **右键（系统托盘）**：右键点击系统托盘中的灵动岛图标，访问设置、切换可见性或退出应用程序。

## 故障排除

- **没有媒体信息？**：确保你的媒体播放器支持 Windows SMTC（大多数浏览器、Spotify 和现代音乐应用都支持）。
- **国产音乐软件（网易云、酷狗等）媒体信息不正常？**：
  > [!WARNING]
  > 网易云，酷狗等国产音乐软件的 SMTC 均无法读取正常的数据，与此相关的 Issue 将会标记为重复。

  **网易云修复方案**：
  1. 确保网易云设置中的 SMTC 选项关闭。
  2. 下载并安装 [BetterNCM](https://github.com/std-microblock/chromatic/releases/tag/1.3.4) (或者 [chromatic](https://github.com/std-microblock/chromatic) 不确定是否能用)。
  3. 安装 [Inflink-rs](https://github.com/apoint123/inflink-rs) 插件。
  4. 在 BetterNCM 的设置中找到 Inflink，打开 SMTC 选项。

  其他音乐软件暂无替代方案，等待更新适配。
- **模糊效果无效？**：检查你的系统是否支持硬件加速，并且是否安装了最新的显卡驱动。
