mod background;
mod expanded;
mod mini;

pub(crate) use mini::{
    lyric_font_size as mini_lyric_font_size, lyric_pair_height as mini_lyric_pair_height,
};

use self::background::{BackgroundParams, draw_background};
use self::expanded::{ExpandedContentParams, draw_expanded_content};
use self::mini::{MiniContentParams, draw_mini_content};

use crate::core::config::{
    CompactWidgetSlot, LyricTransitionAnimation, PluginWidgetSlot, WidgetSlot,
};
use crate::core::lyrics::LyricHighlight;
use crate::core::smtc::MediaInfo;
use crate::ui::compact::CompactOverlay;
use crate::ui::expanded::music_view::{default_media_palette, get_media_palette};
use crate::utils::shape::continuous_rounded_rect_path;
use skia_safe::{ClipOp, Color, Paint, Rect, Surface, gpu::DirectContext, image_filters};

pub struct LayoutParams {
    pub current_w: f32,
    pub current_h: f32,
    pub current_r: f32,
    pub sigmas: (f32, f32),
    pub expansion_progress: f32,
    pub view_offset: f32,
    pub compact_scale: f32,
    pub expanded_scale: f32,
    pub hide_progress: f32,
    pub island_x: f32,
    pub island_y: f32,
    pub stable_island_y: f32,
    pub base_h: f32,
}

pub struct MediaParams<'a> {
    pub media: &'a MediaInfo,
    pub music_active: bool,
    pub available_controls: u32,
}

pub struct LyricsParams<'a> {
    pub current_lyric: &'a str,
    pub current_secondary_lyric: &'a str,
    pub old_lyric: &'a str,
    pub old_secondary_lyric: &'a str,
    pub lyric_highlight: Option<LyricHighlight>,
    pub lyric_transition: f32,
    pub lyric_transition_animation: LyricTransitionAnimation,
    pub lyric_scroll_offset: f32,
}

pub struct StyleParams<'a> {
    pub island_style: &'a str,
    pub host_backdrop: bool,
    pub use_blur: bool,
    pub font_size: f32,
    pub dt: f32,
    pub widget_layout: &'a [WidgetSlot],
    pub plugin_widget_layout: &'a [PluginWidgetSlot],
    pub plugin_widgets: &'a crate::core::plugin_widget::WidgetManager,
    pub compact_widget_layout: &'a [CompactWidgetSlot],
}

use crate::core::context::MiniContent;

const MIN_VISIBLE_OPACITY: f32 = 0.01;
const MIN_BLUR_SIGMA: f32 = 0.1;
const MINI_FADE_RATE: f32 = 1.5;
const COLLAPSED_VISUALIZER_HEIGHT_SCALE: f32 = 0.45;
const BORDER_WIDTH: f32 = 1.0;
const BORDER_INSET: f32 = BORDER_WIDTH / 2.0;
const SOLID_STYLE: &str = "default";
const SOLID_BORDER_ALPHA: u8 = 30;
const EFFECT_BORDER_ALPHA: u8 = 40;

pub struct DrawIslandParams<'a> {
    pub layout: LayoutParams,
    pub media: MediaParams<'a>,
    pub lyrics: LyricsParams<'a>,
    pub mini_content: Option<MiniContent<'a>>,
    pub compact_overlay: &'a CompactOverlay,
    pub style: StyleParams<'a>,
}

pub fn draw_island(
    direct_context: &mut DirectContext,
    surface: &mut Surface,
    params: DrawIslandParams<'_>,
) -> bool {
    let canvas = surface.canvas();
    canvas.clear(Color::TRANSPARENT);
    let layout = &params.layout;
    let rect = Rect::from_xywh(
        layout.island_x,
        layout.island_y,
        layout.current_w,
        layout.current_h,
    );
    let island_path = continuous_rounded_rect_path(rect, layout.current_r);
    let blur_filter = if layout.sigmas.0 > MIN_BLUR_SIGMA || layout.sigmas.1 > MIN_BLUR_SIGMA {
        image_filters::blur(layout.sigmas, None, None, None)
    } else {
        None
    };
    draw_expanded_shadow(canvas, &params, &island_path);
    draw_background_layer(canvas, direct_context, &params, rect, &island_path);
    canvas.save();
    canvas.clip_path(&island_path, ClipOp::Intersect, true);

    let compact_overlay_visible = params.compact_overlay.is_visible();
    let expanded_alpha = if compact_overlay_visible {
        0.0
    } else {
        layout.expansion_progress.powi(2).clamp(0.0, 1.0) * (1.0 - layout.hide_progress)
    };
    let mini_alpha = if compact_overlay_visible {
        0.0
    } else {
        (1.0 - layout.expansion_progress * MINI_FADE_RATE).clamp(0.0, 1.0)
            * (1.0 - layout.hide_progress)
    };
    let palette = if expanded_alpha > MIN_VISIBLE_OPACITY || mini_alpha > MIN_VISIBLE_OPACITY {
        get_media_palette(direct_context, params.media.media)
    } else {
        default_media_palette()
    };
    let visualizer_height_scale = COLLAPSED_VISUALIZER_HEIGHT_SCALE
        + (1.0 - COLLAPSED_VISUALIZER_HEIGHT_SCALE) * layout.expansion_progress;
    let widget_animating = draw_expanded_layer(
        canvas,
        blur_filter,
        &params,
        &palette,
        expanded_alpha,
        visualizer_height_scale,
    );
    if compact_overlay_visible {
        params.compact_overlay.draw(
            canvas,
            rect,
            layout.compact_scale,
            1.0 - layout.hide_progress,
        );
    } else {
        draw_compact_layer(
            canvas,
            &params,
            &palette,
            mini_alpha,
            visualizer_height_scale,
        );
    }
    canvas.restore();
    draw_island_border(canvas, &params);
    widget_animating
}

fn draw_expanded_shadow(
    canvas: &skia_safe::Canvas,
    params: &DrawIslandParams<'_>,
    island_path: &skia_safe::Path,
) {
    let layout = &params.layout;
    let opacity = layout.expansion_progress.clamp(0.0, 1.0).powi(2)
        * (1.0 - layout.hide_progress).clamp(0.0, 1.0);
    if opacity <= MIN_VISIBLE_OPACITY {
        return;
    }
    let scale = layout.expanded_scale;
    let offset_y = 2.0 * scale;
    let bounds = island_path.bounds();
    let surface = canvas.image_info();
    let margin = bounds
        .left()
        .min(surface.width() as f32 - bounds.right())
        .min(bounds.top() + offset_y)
        .min(surface.height() as f32 - bounds.bottom() - offset_y)
        .max(0.0);
    let sigma = (3.0 * scale).min(margin / 3.0);
    let mut paint = Paint::default();
    paint.set_anti_alias(true);
    paint.set_color(Color::from_argb((28.0 * opacity) as u8, 0, 0, 0));
    paint.set_image_filter(image_filters::blur((sigma, sigma), None, None, None));
    canvas.save();
    canvas.clip_path(island_path, ClipOp::Difference, true);
    canvas.translate((0.0, offset_y));
    canvas.draw_path(island_path, &paint);
    canvas.restore();
}

fn draw_background_layer(
    canvas: &skia_safe::Canvas,
    direct_context: &mut DirectContext,
    params: &DrawIslandParams<'_>,
    rect: Rect,
    island_path: &skia_safe::Path,
) {
    draw_background(BackgroundParams {
        canvas,
        direct_context,
        rect,
        island_path,
        island_style: params.style.island_style,
        host_backdrop: params.style.host_backdrop,
        media: params.media.media,
    });
}

fn draw_expanded_layer(
    canvas: &skia_safe::Canvas,
    blur_filter: Option<skia_safe::ImageFilter>,
    params: &DrawIslandParams<'_>,
    palette: &[Color],
    alpha: f32,
    visualizer_height_scale: f32,
) -> bool {
    let layout = &params.layout;
    let media = &params.media;
    let style = &params.style;
    draw_expanded_content(ExpandedContentParams {
        canvas,
        blur_filter,
        expanded_alpha: alpha,
        view_offset: layout.view_offset,
        current_w: layout.current_w,
        offset_x: layout.island_x,
        offset_y: layout.island_y,
        current_h: layout.current_h,
        media: media.media,
        music_active: media.music_active,
        available_controls: media.available_controls,
        global_scale: layout.expanded_scale,
        expansion_progress: layout.expansion_progress,
        viz_h_scale: visualizer_height_scale,
        use_blur: style.use_blur,
        font_size: style.font_size,
        dt: style.dt,
        text_color: Color::WHITE,
        text_color_sec: Color::WHITE,
        palette,
        widget_layout: style.widget_layout,
        plugin_widget_layout: style.plugin_widget_layout,
        plugin_widgets: style.plugin_widgets,
    })
}

fn draw_compact_layer(
    canvas: &skia_safe::Canvas,
    params: &DrawIslandParams<'_>,
    palette: &[Color],
    alpha: f32,
    visualizer_height_scale: f32,
) {
    let layout = &params.layout;
    let lyrics = &params.lyrics;
    let style = &params.style;
    let has_mini_content = params.mini_content.is_some();
    let center_occupied = crate::ui::widget::compact::has_center_widget(
        style.compact_widget_layout,
        has_mini_content,
    );
    let visible_mini_content = if center_occupied {
        None
    } else {
        params.mini_content
    };
    let (left_extension, right_extension) = crate::ui::widget::compact::side_extensions(
        style.compact_widget_layout,
        center_occupied || has_mini_content,
        has_mini_content,
    );
    let left_extension = left_extension * layout.compact_scale;
    let right_extension = right_extension * layout.compact_scale;
    draw_mini_content(MiniContentParams {
        canvas,
        content: visible_mini_content,
        mini_alpha: alpha,
        current_w: (layout.current_w - left_extension - right_extension).max(0.0),
        global_scale: layout.compact_scale,
        media: params.media.media,
        offset_x: layout.island_x + left_extension,
        stable_offset_y: layout.stable_island_y,
        base_h: layout.base_h,
        palette,
        viz_h_scale: visualizer_height_scale,
        current_lyric: lyrics.current_lyric,
        current_secondary_lyric: lyrics.current_secondary_lyric,
        old_lyric: lyrics.old_lyric,
        old_secondary_lyric: lyrics.old_secondary_lyric,
        lyric_highlight: lyrics.lyric_highlight,
        expansion_progress: layout.expansion_progress,
        font_size: style.font_size,
        lyric_scroll_offset: lyrics.lyric_scroll_offset,
        lyric_transition: lyrics.lyric_transition,
        lyric_transition_animation: lyrics.lyric_transition_animation,
        text_color: Color::WHITE,
    });
    crate::ui::widget::compact::draw(
        canvas,
        style.compact_widget_layout,
        Rect::from_xywh(
            layout.island_x,
            layout.stable_island_y,
            layout.current_w,
            layout.base_h,
        ),
        layout.compact_scale,
        (alpha * f32::from(u8::MAX)) as u8,
        has_mini_content,
    );
}

fn draw_island_border(canvas: &skia_safe::Canvas, params: &DrawIslandParams<'_>) {
    let layout = &params.layout;
    let mut paint = Paint::default();
    paint.set_anti_alias(true);
    paint.set_style(skia_safe::PaintStyle::Stroke);
    paint.set_stroke_width(BORDER_WIDTH);
    let alpha = if params.style.island_style == SOLID_STYLE {
        SOLID_BORDER_ALPHA
    } else {
        EFFECT_BORDER_ALPHA
    };
    let opacity = if params.style.island_style == SOLID_STYLE {
        1.0 - layout.expansion_progress.clamp(0.0, 1.0)
    } else {
        1.0
    };
    paint.set_color(Color::from_argb(
        (alpha as f32 * opacity) as u8,
        u8::MAX,
        u8::MAX,
        u8::MAX,
    ));
    let border_path = continuous_rounded_rect_path(
        Rect::from_xywh(
            layout.island_x + BORDER_INSET,
            layout.island_y + BORDER_INSET,
            (layout.current_w - BORDER_WIDTH).max(0.0),
            (layout.current_h - BORDER_WIDTH).max(0.0),
        ),
        (layout.current_r - BORDER_INSET).max(0.0),
    );
    canvas.draw_path(&border_path, &paint);
}
