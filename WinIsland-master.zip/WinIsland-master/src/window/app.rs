use crate::core::audio::AudioProcessor;
use crate::core::config::{AppConfig, LyricTransitionAnimation, LyricTransitionMode};
use crate::core::context::ContextManager;
use crate::core::lyrics::LyricHighlight;
use crate::core::persistence::{get_config_path, load_config};
use crate::core::plugin_widget::WidgetManager;
use crate::core::smtc::{MediaInfo, SmtcListener};
use crate::plugin::PluginManager;
use crate::plugin::marketplace::MarketplaceCatalog;
use crate::plugin::zip_loader::PluginManifest;
use crate::ui::compact::CompactOverlay;
use crate::utils::physics::Spring;
use crate::window::d3d::D3DRenderer;
use crate::window::settings::SettingsApp;
use crate::window::tray::TrayManager;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::mpsc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use winit::dpi::PhysicalPosition;
use winit::window::Window;

mod events;
mod frame;
mod input;
mod layout;
mod lifecycle;
mod startup;
mod system;

type InstallResult = Result<(PluginManifest, PathBuf), String>;
type MarketplaceCatalogResult = Result<MarketplaceCatalog, String>;
type MarketplaceDownloadResult = Result<PathBuf, String>;
const RIGHT_DRAG_THRESHOLD: i32 = 4;
const DOUBLE_CLICK_DISTANCE: f32 = 8.0;
pub(super) const DEFAULT_ANIMATION_REFRESH_RATE_MILLIHERTZ: u32 = 144_000;
pub(super) const DEFAULT_ANIMATION_FRAME_INTERVAL: Duration = Duration::from_micros(6_944);

fn should_show_widget_view(music_page_available: bool) -> bool {
    !music_page_available
}

struct PluginMediaSource {
    resource_id: u64,
    available_controls: u32,
    info: MediaInfo,
}

pub struct App {
    window: Option<Arc<Window>>,
    renderer: Option<D3DRenderer>,
    settings: Option<SettingsApp>,
    tray: Option<TrayManager>,
    smtc: SmtcListener,
    audio: AudioProcessor,
    compact_overlay: CompactOverlay,
    config: AppConfig,
    expanded: bool,
    widget_view: bool,
    music_page_available: bool,
    visible: bool,
    springs: IslandSprings,
    geom: WindowGeometry,
    smtc_media_info: MediaInfo,
    last_media_title: String,
    lyrics: LyricState,
    idle_timer: Instant,
    last_effect_refresh: Instant,
    hide: HideState,
    is_dragging: bool,
    dismissing_notification: bool,
    drag_start_px: i32,
    drag_start_py: i32,
    drag_start_hide_val: f32,
    drag_has_moved: bool,
    last_update_time: Instant,
    last_render_time: Instant,
    last_topmost_check: Instant,
    renderer_retry_at: Option<Instant>,
    last_fullscreen_check: Instant,
    last_config_check: Instant,
    last_monitor_check: Instant,
    last_working_set_trim: Instant,
    compact_widget_refresh_at: Instant,
    last_config_modified: Option<SystemTime>,
    next_frame_deadline: Instant,
    animation_frame_interval: Duration,
    width_hiding_last_frame: bool,
    restoring_hide_width: bool,
    seek: SeekDrag,
    is_fullscreen_suppressed: bool,
    is_cursor_suppressed: bool,
    hidden_reveal_click: HiddenRevealClick,
    cover_click: DoubleClick,
    touch_id: Option<u64>,
    touch_pos: PhysicalPosition<f64>,
    ctx_mgr: ContextManager,
    widget_mgr: WidgetManager,
    plugin_mgr: PluginManager,
    plugin_media_source: Option<PluginMediaSource>,
    is_light_theme: bool,
    pending_install: Option<mpsc::Receiver<InstallResult>>,
    marketplace_catalog: Option<MarketplaceCatalog>,
    pending_marketplace_catalog: Option<mpsc::Receiver<MarketplaceCatalogResult>>,
    pending_marketplace_download: Option<mpsc::Receiver<MarketplaceDownloadResult>>,
    right_press_cursor: Option<(i32, i32)>,
    is_right_dragging: bool,
    right_drag_start_offset: Option<(i32, i32)>,
}

impl Default for App {
    fn default() -> Self {
        let config = load_config();
        let last_config_modified = std::fs::metadata(get_config_path())
            .and_then(|metadata| metadata.modified())
            .ok();
        crate::utils::font::FontManager::global()
            .set_custom_font_path(config.custom_font_path.as_deref());
        Self {
            window: None,
            renderer: None,
            settings: None,
            tray: None,
            config: config.clone(),
            expanded: false,
            widget_view: false,
            music_page_available: false,
            visible: true,
            springs: IslandSprings::new(&config),
            geom: WindowGeometry::default(),
            smtc: SmtcListener::new(
                config.smtc_enabled,
                config.lyrics_mode.clone(),
                config.lyrics_source.clone(),
                config.lyrics_local_dir.clone(),
                config.smtc_apps.clone(),
                config.smtc_known_apps.clone(),
            ),
            audio: AudioProcessor::new(),
            compact_overlay: CompactOverlay::new(config.replace_native_volume_flyout),
            smtc_media_info: MediaInfo::default(),
            last_media_title: String::new(),
            lyrics: LyricState::default(),
            idle_timer: Instant::now(),
            last_effect_refresh: Instant::now(),
            hide: HideState::default(),
            is_dragging: false,
            dismissing_notification: false,
            drag_start_px: 0,
            drag_start_py: 0,
            drag_start_hide_val: 0.0,
            drag_has_moved: false,
            last_update_time: Instant::now(),
            last_render_time: Instant::now(),
            last_topmost_check: Instant::now(),
            renderer_retry_at: None,
            last_fullscreen_check: Instant::now(),
            last_config_check: Instant::now(),
            last_monitor_check: Instant::now(),
            last_working_set_trim: Instant::now(),
            compact_widget_refresh_at: Instant::now(),
            last_config_modified,
            next_frame_deadline: Instant::now(),
            animation_frame_interval: DEFAULT_ANIMATION_FRAME_INTERVAL,
            width_hiding_last_frame: false,
            restoring_hide_width: false,
            seek: SeekDrag::default(),
            is_fullscreen_suppressed: false,
            is_cursor_suppressed: false,
            hidden_reveal_click: HiddenRevealClick::default(),
            cover_click: DoubleClick::default(),
            touch_id: None,
            touch_pos: PhysicalPosition::new(0.0, 0.0),
            ctx_mgr: ContextManager::new(),
            widget_mgr: WidgetManager::new(),
            plugin_mgr: PluginManager::default(),
            plugin_media_source: None,
            is_light_theme: false,
            pending_install: None,
            marketplace_catalog: None,
            pending_marketplace_catalog: None,
            pending_marketplace_download: None,
            right_press_cursor: None,
            is_right_dragging: false,
            right_drag_start_offset: None,
        }
    }
}

#[derive(Default)]
struct HiddenRevealClick {
    left_pressed: bool,
    sequence: DoubleClick,
}

impl HiddenRevealClick {
    fn update(
        &mut self,
        active: bool,
        left_pressed: bool,
        position: (f32, f32),
        now: Instant,
        interval: Duration,
    ) -> bool {
        let pressed = left_pressed && !self.left_pressed;
        self.left_pressed = left_pressed;
        if !active {
            self.sequence.reset();
            return false;
        }
        if !pressed {
            return false;
        }
        self.sequence.register(position, now, interval)
    }
}

#[derive(Default)]
struct DoubleClick {
    first_click: Option<(Instant, f32, f32)>,
}

impl DoubleClick {
    fn register(&mut self, position: (f32, f32), now: Instant, interval: Duration) -> bool {
        let (x, y) = position;
        if let Some((first, first_x, first_y)) = self.first_click.take()
            && now.saturating_duration_since(first) <= interval
            && (x - first_x).abs() <= DOUBLE_CLICK_DISTANCE
            && (y - first_y).abs() <= DOUBLE_CLICK_DISTANCE
        {
            return true;
        }
        self.first_click = Some((now, x, y));
        false
    }

    fn reset(&mut self) {
        self.first_click = None;
    }
}

#[derive(Default)]
struct WindowGeometry {
    os_w: u32,
    os_h: u32,
    win_x: i32,
    win_y: i32,
    configured_x: i32,
    configured_y: i32,
    monitor_size: (u32, u32),
    monitor_pos: (i32, i32),
    position_restore_after: Option<Instant>,
}

#[derive(Default)]
struct SeekDrag {
    active: bool,
    bar_left: f32,
    bar_right: f32,
    duration_ms: u64,
    preview_ms: u64,
    media_resource_id: Option<crate::plugin::types::ResourceId>,
}

impl SeekDrag {
    fn begin(
        &mut self,
        bar_left: f32,
        bar_right: f32,
        duration_ms: u64,
        preview_ms: u64,
        media_resource_id: Option<crate::plugin::types::ResourceId>,
    ) {
        self.active = true;
        self.bar_left = bar_left;
        self.bar_right = bar_right;
        self.duration_ms = duration_ms;
        self.preview_ms = preview_ms;
        self.media_resource_id = media_resource_id;
    }

    fn preview_at(&mut self, click_x: f32) {
        let bar_width = self.bar_right - self.bar_left;
        let ratio = if bar_width > 0.0 {
            ((click_x - self.bar_left) / bar_width).clamp(0.0, 1.0)
        } else {
            0.0
        };
        self.preview_ms = (ratio as f64 * self.duration_ms as f64) as u64;
    }
}

struct LyricState {
    current_text: String,
    current_secondary_text: String,
    old_text: String,
    old_secondary_text: String,
    highlight: Option<LyricHighlight>,
    transition: f32,
    transition_animation: LyricTransitionAnimation,
    random_state: u64,
    scroll_offset: f32,
    scroll_pause: f32,
}

impl Default for LyricState {
    fn default() -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default();
        let random_state =
            (now.as_secs() ^ (u64::from(now.subsec_nanos()) << 32) ^ u64::from(std::process::id()))
                .max(1);
        Self {
            current_text: String::new(),
            current_secondary_text: String::new(),
            old_text: String::new(),
            old_secondary_text: String::new(),
            highlight: None,
            transition: 1.0,
            transition_animation: LyricTransitionAnimation::Blur,
            random_state,
            scroll_offset: 0.0,
            scroll_pause: 0.0,
        }
    }
}

impl LyricState {
    fn transition_to(
        &mut self,
        text: String,
        secondary_text: String,
        highlight: Option<LyricHighlight>,
        show_immediately: bool,
        transition_mode: LyricTransitionMode,
    ) {
        self.old_text = std::mem::replace(&mut self.current_text, text);
        self.old_secondary_text =
            std::mem::replace(&mut self.current_secondary_text, secondary_text);
        self.highlight = highlight;
        self.transition = if show_immediately { 1.0 } else { 0.0 };
        let random_value = self.next_random();
        self.transition_animation = transition_mode.animation(random_value);
        self.scroll_offset = 0.0;
        self.scroll_pause = 0.0;
    }

    fn next_random(&mut self) -> u64 {
        let mut value = self.random_state;
        value ^= value << 13;
        value ^= value >> 7;
        value ^= value << 17;
        self.random_state = value;
        value
    }
}

#[derive(Default)]
struct HideState {
    auto: bool,
    manual: bool,
    fullscreen: bool,
    fullscreen_reveal_override: bool,
    notification_reveal: bool,
    origin: Option<(i32, i32)>,
}

impl HideState {
    fn is_hidden(&self) -> bool {
        self.has_hidden_reason() && !self.notification_reveal
    }

    fn has_hidden_reason(&self) -> bool {
        self.auto || self.fullscreen || self.manual
    }
}

struct IslandSprings {
    w: Spring,
    h: Spring,
    r: Spring,
    view: Spring,
    hide: Spring,
    expanded_target: bool,
}

impl IslandSprings {
    const EQUAL_WIDTH_THRESHOLD_RATIO: f32 = 0.02;
    const EQUAL_WIDTH_EXPANSION_IMPULSE_RATIO: f32 = 0.012;

    fn new(config: &AppConfig) -> Self {
        Self {
            w: Spring::new(config.base_width * config.compact_scale),
            h: Spring::new(config.base_height * config.compact_scale),
            r: Spring::new((config.base_height * config.compact_scale) / 2.0),
            view: Spring::new(0.0),
            hide: Spring::new(0.0),
            expanded_target: false,
        }
    }

    fn retarget_expansion(
        &mut self,
        expanded: bool,
        target_w: f32,
        target_h: f32,
        target_r: f32,
        target_view: f32,
    ) {
        if self.expanded_target == expanded {
            return;
        }
        self.expanded_target = expanded;
        if expanded
            && (target_w - self.w.value).abs() <= target_w * Self::EQUAL_WIDTH_THRESHOLD_RATIO
        {
            self.w.velocity = target_w * Self::EQUAL_WIDTH_EXPANSION_IMPULSE_RATIO;
        } else {
            self.w.redirect_velocity_towards(target_w);
        }
        self.h.redirect_velocity_towards(target_h);
        self.r.redirect_velocity_towards(target_r);
        self.view.redirect_velocity_towards(target_view);
    }

    fn any_animating(&self) -> bool {
        self.w.velocity.abs() > 0.001
            || self.h.velocity.abs() > 0.001
            || self.r.velocity.abs() > 0.001
            || self.view.velocity.abs() > 0.001
            || self.hide.velocity.abs() > 0.001
    }
}

struct IslandLayout {
    offset_x: f64,
    island_y: f64,
    current_island_x: f64,
    current_island_y: f64,
    stable_island_y: f64,
    hide_distance: f64,
    content_hide_ratio: f32,
    hidden_reveal_x: f64,
    hidden_reveal_y: f64,
    hidden_reveal_w: f64,
    hidden_reveal_h: f64,
}

impl App {
    fn current_media_info(&self) -> &MediaInfo {
        self.plugin_media_source
            .as_ref()
            .map_or(&self.smtc_media_info, |source| &source.info)
    }

    fn media_control_available(&self, control: u32) -> bool {
        self.plugin_media_source
            .as_ref()
            .map_or(self.config.smtc_enabled, |source| {
                source.available_controls & control != 0
            })
    }

    fn media_active(&self) -> bool {
        if let Some(source) = &self.plugin_media_source {
            return !source.info.title.is_empty();
        }
        self.config.smtc_enabled && !self.smtc_media_info.title.is_empty()
    }

    fn audio_target_app_id(&self) -> &str {
        if self.plugin_media_source.is_some() || !self.config.smtc_enabled {
            ""
        } else {
            &self.smtc_media_info.source_app_id
        }
    }

    fn dispatch_media_command(&self, command: u32, position_ms: u64) {
        if let Some(source) = &self.plugin_media_source {
            if let Err(error) = crate::plugin::manager::dispatch_media_command(
                source.resource_id,
                command,
                position_ms,
            ) {
                log::warn!("Plugin media command failed: {error}");
            }
            return;
        }
        match command {
            crate::plugin::types::MEDIA_COMMAND_TOGGLE_PLAY => self.smtc.request_toggle_play(),
            crate::plugin::types::MEDIA_COMMAND_PREVIOUS => self.smtc.request_prev(),
            crate::plugin::types::MEDIA_COMMAND_NEXT => self.smtc.request_next(),
            crate::plugin::types::MEDIA_COMMAND_SEEK => self.smtc.request_seek(position_ms),
            _ => (),
        }
    }

    fn dispatch_seek_command(&mut self) {
        let position_ms = self.seek.preview_ms.min(self.seek.duration_ms);
        if let Some(resource_id) = self.seek.media_resource_id {
            if let Err(error) = crate::plugin::manager::dispatch_media_command(
                resource_id,
                crate::plugin::types::MEDIA_COMMAND_SEEK,
                position_ms,
            ) {
                log::warn!("Plugin media seek failed: {error}");
            } else if let Some(source) = self
                .plugin_media_source
                .as_mut()
                .filter(|source| source.resource_id == resource_id)
            {
                source.info.apply_seek(position_ms);
            }
        } else {
            self.smtc.request_seek(position_ms);
            self.smtc_media_info.apply_seek(position_ms);
        }
    }

    fn finish_seek(&mut self) -> bool {
        if !self.seek.active {
            return false;
        }
        self.seek.active = false;
        if self.seek.duration_ms > 0 {
            self.seek.preview_ms = self.seek.preview_ms.min(self.seek.duration_ms);
            crate::ui::expanded::music_view::snap_progress(
                self.seek.preview_ms as f32 / self.seek.duration_ms as f32,
            );
            self.dispatch_seek_command();
        }
        true
    }

    fn is_hidden(&self) -> bool {
        self.hide.is_hidden()
    }

    fn is_width_hiding(&self) -> bool {
        self.is_hidden() || (self.is_dragging && self.hide.origin.is_some())
    }

    fn reveal_island(&mut self) {
        self.hide.auto = false;
        self.hide.fullscreen = false;
        self.hide.manual = false;
        self.hide.notification_reveal = false;
        if self.is_fullscreen_suppressed {
            self.hide.fullscreen_reveal_override = true;
        }
        self.springs.hide.velocity = -0.65;
        self.idle_timer = Instant::now();
    }
}
